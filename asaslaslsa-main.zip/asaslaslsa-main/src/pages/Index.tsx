import { useState } from "react";
import SlideshowLanding from "@/components/SlideshowLanding";
import SlideshowViewer from "@/components/SlideshowViewer";

const Index = () => {
  const [isSlideshow, setIsSlideshow] = useState(false);

  const handleStartSlideshow = () => {
    setIsSlideshow(true);
  };

  const handleExitSlideshow = () => {
    setIsSlideshow(false);
  };

  return (
    <>
      {isSlideshow ? (
        <SlideshowViewer onExit={handleExitSlideshow} />
      ) : (
        <SlideshowLanding onStart={handleStartSlideshow} />
      )}
    </>
  );
};

export default Index;
