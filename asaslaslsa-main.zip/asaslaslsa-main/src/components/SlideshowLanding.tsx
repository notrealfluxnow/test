import { Button } from "@/components/ui/button";
import { Play, Users, Lightbulb } from "lucide-react";
import { useState } from "react";
interface SlideshowLandingProps {
  onStart: () => void;
}
const SlideshowLanding = ({
  onStart
}: SlideshowLandingProps) => {
  const [isStarting, setIsStarting] = useState(false);

  const handleStart = async () => {
    setIsStarting(true);
    
    // Request fullscreen
    try {
      if (document.documentElement.requestFullscreen) {
        await document.documentElement.requestFullscreen();
      }
    } catch (error) {
      console.log("Fullscreen not supported or denied");
    }
    
    setTimeout(() => {
      onStart();
    }, 500);
  };
  return <div className={`h-screen flex items-center justify-center relative overflow-hidden transition-opacity duration-500 ${isStarting ? 'opacity-0' : 'opacity-100'}`}>
      {/* Background Elements */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-primary/20 rounded-full blur-3xl" style={{
        animation: 'float 12s ease-in-out infinite',
        animationDelay: '0s'
      }} />
        <div className="absolute bottom-1/4 right-1/4 w-48 h-48 bg-accent/20 rounded-full blur-3xl" style={{
        animation: 'float 12s ease-in-out infinite',
        animationDelay: '2s'
      }} />
        <div className="absolute top-1/2 right-1/3 w-32 h-32 bg-primary/30 rounded-full blur-2xl" style={{
        animation: 'float 12s ease-in-out infinite',
        animationDelay: '4s'
      }} />
      </div>

      {/* Main Content */}
      <div className="text-center z-10 max-w-2xl mx-auto px-8">
        {/* Logo/Title Area */}
        <div className="mb-6" style={{animation: 'float 10s ease-in-out infinite'}}>
          <div className="glass-card p-6 mb-6 glow-effect">
            <Lightbulb className="w-12 h-12 mx-auto mb-3 text-primary animate-pulse" />
            <h1 className="text-4xl font-bold mb-3 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">Becoming an Entrepreneur</h1>
            <p className="text-lg text-muted-foreground">
              From ideas to businesses: the journey of entrepreneurs
            </p>
          </div>
        </div>

        {/* Start Button */}
        <div className="mb-6">
          <Button onClick={handleStart} className="start-button group relative" size="lg" disabled={isStarting}>
            <Play className="w-6 h-6 mr-3 group-hover:scale-110 transition-transform" />
            Becoming an Entrepreneur
            <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-primary/0 via-white/10 to-primary/0 
                          opacity-0 group-hover:opacity-100 transition-opacity blur-xl" />
          </Button>
        </div>

        {/* Team Info */}
        <div className="glass-card p-4" style={{
        animation: 'float 10s ease-in-out infinite',
        animationDelay: '1s'
      }}>
          <div className="flex items-center justify-center mb-3">
            <Users className="w-5 h-5 mr-2 text-primary" />
            <h3 className="text-lg font-semibold">Created by</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3 text-sm">
            <div className="p-2 rounded-xl bg-secondary/30">
              <div className="font-medium text-primary text-lg">Saeid Mohammad</div>
              <div className="text-muted-foreground text-xs">Website Designer</div>
            </div>
            <div className="p-2 rounded-xl bg-secondary/30">
              <div className="font-medium text-primary text-lg">Mohamed Samir</div>
              <div className="text-muted-foreground text-xs">Context</div>
            </div>
            <div className="p-2 rounded-xl bg-secondary/30">
              <div className="font-medium text-primary text-lg">Abdullah Abbas</div>
              <div className="text-muted-foreground text-xs">Poem and Poster</div>
            </div>
            <div className="p-2 rounded-xl bg-secondary/30">
              <div className="font-medium text-primary text-lg">Hamid Abdolrahim</div>
              <div className="text-muted-foreground text-xs">Pictures</div>
            </div>
            <div className="p-2 rounded-xl bg-secondary/30">
              <div className="font-medium text-primary text-lg">Abdalla Aziz</div>
              <div className="text-muted-foreground text-xs">Pictures</div>
            </div>
          </div>
        </div>

        {/* Floating Preview Cards */}
        <div className="absolute left-4 top-1/2 -translate-y-1/2 opacity-20">
          <div className="slide-card previous w-32 h-20 bg-secondary/50" />
        </div>
        <div className="absolute right-4 top-1/2 -translate-y-1/2 opacity-20">
          <div className="slide-card next w-32 h-20 bg-secondary/50" />
        </div>
      </div>
    </div>;
};
export default SlideshowLanding;