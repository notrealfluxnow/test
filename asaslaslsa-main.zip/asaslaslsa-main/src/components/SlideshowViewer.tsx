import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogTrigger } from "@/components/ui/dialog";
import { ChevronLeft, ChevronRight, X, Home, Play } from "lucide-react";

// Import slide images
import slide1 from "@/assets/slide-1.png";
import slide2 from "@/assets/slide-2.png";
import slide3 from "@/assets/slide-3.png";
import slide4 from "@/assets/slide-4.png";
import slide5 from "@/assets/slide-5.png";
import slide6 from "@/assets/slide-6.png";
import slide7 from "@/assets/slide-7-poem.png";
import slide8 from "@/assets/slide-7.png";
import slide9 from "@/assets/slide-8.png";
import poemFull from "@/assets/poem-full.jpg";
interface Slide {
  id: number;
  title: string;
  content: string;
  image: string;
  background?: string;
}
interface SlideshowViewerProps {
  onExit: () => void;
}
const SlideshowViewer = ({
  onExit
}: SlideshowViewerProps) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [isVideoOpen, setIsVideoOpen] = useState(false);
  const [isPoemOpen, setIsPoemOpen] = useState(false);

  // Entrepreneurship presentation slides
  const slides: Slide[] = [{
    id: 1,
    title: "Becoming an Entrepreneur",
    content: "Presented by: Saeid Mohammad, Mohamed Samir, Abdullah Abbas, Hamid Abdolrahim, and Mx Abdalla Aziz",
    image: slide1,
    background: "from-blue-900/10 to-purple-900/10"
  }, {
    id: 2,
    title: "What is an Entrepreneur?",
    content: "An entrepreneur is a person who starts and manages a business, taking financial risks in the hope of making a profit. They come up with new ideas, organize resources, and create value through their products or services.",
    image: slide2,
    background: "from-purple-900/10 to-pink-900/10"
  }, {
    id: 3,
    title: "Key Entrepreneurial Qualities",
    content: "Creativity and Innovation to bring new ideas • Determination and Persistence to overcome difficulties • Leadership and Decision-Making Skills to manage people and resources",
    image: slide3,
    background: "from-pink-900/10 to-red-900/10"
  }, {
    id: 4,
    title: "Steps to Start a Business",
    content: "Choose a business activity and legal structure • Register the trade name and obtain initial approvals • Apply for a business license, arrange office space, and open a bank account",
    image: slide4,
    background: "from-red-900/10 to-orange-900/10"
  }, {
    id: 5,
    title: "Job Opportunities and Economic Growth",
    content: "It creates job opportunities for citizens and residents • It drives innovation and diversification beyond oil • It attracts investment and strengthens global competitiveness",
    image: slide5,
    background: "from-orange-900/10 to-yellow-900/10"
  }, {
    id: 6,
    title: "Entrepreneurs in the UAE",
    content: "Entrepreneurs in the UAE face several challenges including high costs of setup and operation, intense competition from local and international businesses, and complex legal requirements and government regulations.",
    image: slide6,
    background: "from-yellow-900/10 to-green-900/10"
  }, {
    id: 7,
    title: "A Poem on Entrepreneur",
    content: "A creative perspective on entrepreneurship through poetry, showcasing the artistic side of business innovation.",
    image: slide7,
    background: "from-green-900/10 to-teal-900/10"
  }, {
    id: 8,
    title: "Let's Watch a Short Video",
    content: "Time for an interactive video segment to enhance our understanding of entrepreneurship and real-world applications.",
    image: slide8,
    background: "from-teal-900/10 to-cyan-900/10"
  }, {
    id: 9,
    title: "Thank You",
    content: "Thank you for your time and attention. We hope this presentation has provided valuable insights into the entrepreneurial journey.",
    image: slide9,
    background: "from-cyan-900/10 to-blue-900/10"
  }];
  const nextSlide = useCallback(() => {
    if (isTransitioning) return;
    setIsTransitioning(true);
    setCurrentSlide(prev => (prev + 1) % slides.length);
    setTimeout(() => setIsTransitioning(false), 600);
  }, [slides.length, isTransitioning]);
  const prevSlide = useCallback(() => {
    if (isTransitioning) return;
    setIsTransitioning(true);
    setCurrentSlide(prev => (prev - 1 + slides.length) % slides.length);
    setTimeout(() => setIsTransitioning(false), 600);
  }, [slides.length, isTransitioning]);
  const goToSlide = useCallback((index: number) => {
    if (isTransitioning || index === currentSlide) return;
    setIsTransitioning(true);
    setCurrentSlide(index);
    setTimeout(() => setIsTransitioning(false), 600);
  }, [currentSlide, isTransitioning]);

  // Keyboard navigation
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowRight':
        case ' ':
          e.preventDefault();
          nextSlide();
          break;
        case 'ArrowLeft':
          e.preventDefault();
          prevSlide();
          break;
        case 'Escape':
          onExit();
          break;
      }
    };
    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [nextSlide, prevSlide, onExit]);
  const getSlidePosition = (index: number) => {
    const diff = index - currentSlide;
    if (diff === 0) return 'current';
    if (diff === 1 || diff === -(slides.length - 1)) return 'next';
    if (diff === -1 || diff === slides.length - 1) return 'previous';
    return 'hidden';
  };
  return <div className="fixed inset-0 z-50 bg-background overflow-hidden">
      {/* Background with gradient */}
      <div className={`absolute inset-0 bg-gradient-to-br ${slides[currentSlide].background} transition-all duration-700 ease-out`} />
      
      {/* Floating background elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl" style={{
        animation: 'float 12s ease-in-out infinite'
      }} />
        <div className="absolute bottom-1/4 right-1/4 w-64 h-64 bg-accent/10 rounded-full blur-3xl" style={{
        animation: 'float 12s ease-in-out infinite',
        animationDelay: '3s'
      }} />
      </div>

      {/* Exit Button */}
      

      {/* Home Button */}
      

      {/* Navigation Arrows */}
      <button onClick={prevSlide} disabled={isTransitioning} className="navigation-arrow left-8 disabled:opacity-50 disabled:cursor-not-allowed">
        <ChevronLeft className="w-6 h-6" />
      </button>

      <button onClick={nextSlide} disabled={isTransitioning} className="navigation-arrow right-8 disabled:opacity-50 disabled:cursor-not-allowed">
        <ChevronRight className="w-6 h-6" />
      </button>

      {/* Slides Container */}
      <div className="relative h-full flex items-center justify-center perspective-1000">
        <div className="relative w-full max-w-7xl mx-auto px-8">
          {slides.map((slide, index) => {
          const position = getSlidePosition(index);
          return <div key={slide.id} className={`slide-card ${position} absolute left-0 right-0 top-1/2 -mt-64 md:-mt-80 mx-auto w-full max-w-6xl p-16 flex flex-col justify-center text-gray-800`} style={{
            transformStyle: 'preserve-3d',
            height: '32rem'
          }}>
                <div className="text-center relative">
                  <img 
                    src={slide.image} 
                    alt={slide.title}
                    className="w-full h-full object-contain rounded-lg shadow-2xl max-h-[80vh]"
                    draggable={false}
                  />
                  {slide.id === 7 && (
                    <Dialog open={isPoemOpen} onOpenChange={setIsPoemOpen}>
                      <DialogTrigger asChild>
                        <button className="absolute top-[25%] left-1/2 -translate-x-1/2 w-80 h-20 bg-gradient-to-br from-amber-700 to-orange-800 rounded-2xl shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-105 border border-amber-600/30">
                          <span className="text-white font-semibold text-lg">
                            View Full Poem
                          </span>
                        </button>
                      </DialogTrigger>
                      <DialogContent className="!max-w-none !w-screen !h-screen !p-0 !border-0 !bg-transparent !gap-0 !translate-x-[-50%] !translate-y-[-50%] !left-[50%] !top-[50%] !fixed !z-50 overflow-hidden flex items-center justify-center">
                        <img 
                          src={poemFull} 
                          alt="The Spirit of Entrepreneurship - Full Poem"
                          className="max-w-full max-h-full object-contain"
                        />
                      </DialogContent>
                    </Dialog>
                  )}
                  {slide.id === 8 && (
                    <Dialog open={isVideoOpen} onOpenChange={setIsVideoOpen}>
                      <DialogTrigger asChild>
                        <button className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 p-1 w-52 h-16 bg-primary border-2 border-primary-foreground rounded-md text-xs cursor-pointer">
                          <span className="relative flex justify-center items-center bottom-1.5 w-52 h-16 bg-primary rounded-sm text-2xl text-primary-foreground border-2 border-primary-foreground shadow-[0_0.4em_0.1em_0.019em] shadow-primary-foreground hover:translate-y-1.5 hover:shadow-none transition-all duration-500">
                            <Play className="w-6 h-6 mr-2" />
                            Watch Video
                          </span>
                        </button>
                      </DialogTrigger>
                      <DialogContent className="max-w-4xl w-full p-0">
                        <div className="aspect-video w-full">
                          <iframe 
                            width="100%" 
                            height="100%" 
                            src="https://www.youtube.com/embed/lJjILQu2xM8?si=y-mkK6nYn1F2Ugf7" 
                            title="YouTube video player" 
                            allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" 
                            referrerPolicy="strict-origin-when-cross-origin" 
                            allowFullScreen
                            className="rounded-lg"
                          />
                        </div>
                      </DialogContent>
                    </Dialog>
                  )}
                </div>
              </div>;
        })}
        </div>
      </div>

      {/* Slide Indicators */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex space-x-3 z-30">
        {slides.map((_, index) => <button key={index} onClick={() => goToSlide(index)} disabled={isTransitioning} className={`slide-indicator ${index === currentSlide ? 'active' : ''} disabled:cursor-not-allowed`} />)}
      </div>

      {/* Slide Counter */}
      <div className="absolute bottom-8 right-8 glass-card px-4 py-2 text-sm">
        {currentSlide + 1} / {slides.length}
      </div>

      {/* Progress Bar */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-secondary/30">
        <div className="h-full bg-gradient-to-r from-primary to-accent transition-all duration-700 ease-out" style={{
        width: `${(currentSlide + 1) / slides.length * 100}%`
      }} />
      </div>
    </div>;
};
export default SlideshowViewer;